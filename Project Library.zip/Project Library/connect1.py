import mysql.connector
conn = mysql.connector.connect\
        (host= "localhost", user = "root",passwd= "1234",auth_plugin='mysql_native_password',database='library')  
MyCur=conn.cursor()
def updateTable(query):    
    MyCur.execute(query)
    conn.commit()
def getInfo(query):
    MyCur.execute(query)
    return MyCur 
def delete(query):
    MyCur.execute(query)
    conn.commit()
def update(query):
    MyCur.execute(query)
    conn.commit()

def search(query):
    MyCur.execute(query)
    return MyCur