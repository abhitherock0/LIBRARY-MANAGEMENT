# import mysql.connector
import tkinter as tk
from tkinter import ttk
# import myconnect as d
def register2():
    root=tk.Toplevel()
    ttk.Label(root,text="Issue Book").pack()
    l=ttk.Label(root)
    root.iconbitmap("abhi.ico")
    root.geometry('800x800+200+200')
    ttk.Label(root,text="Issuance Id").pack()
    m=tk.IntVar()
    enter_id=ttk.Entry(root,textvariable=m)
    enter_id.focus()
    enter_id.pack()

    ttk.Label(root,text="Book Id").pack()
    n=tk.IntVar()
    enter_bid=ttk.Entry(root,textvariable=n)
    enter_bid.focus()
    enter_bid.pack()

    ttk.Label(root,text="Student Id").pack()
    o=tk.IntVar()
    enter_sid=ttk.Entry(root,textvariable=o)
    enter_sid.focus()
    enter_sid.pack()

    ttk.Label(root,text="Issuance Date").pack()
    p=tk.StringVar()
    enter_date=ttk.Entry(root,textvariable=p)
    enter_date.focus()
    enter_date.pack()

    ttk.Label(root,text="Return Date").pack()
    q=tk.StringVar()
    enter_rdate=ttk.Entry(root,textvariable=q)
    enter_rdate.focus()
    enter_rdate.pack()

    def insert2():
        # try:
            m=enter_id.get()
            n=enter_bid.get()
            o=enter_sid.get()
            p=enter_date.get()
            q=enter_rdate.get()
            query=f"insert into issuebook values({m},{n},{o},'{p}','{q}')"
            # MyCur=d.updateInfo(query)
            # if type(MyCur) is int:
            #     result_label.set("Inserted Success")
            # else:
            #     result_label.set(MyCur)

    register_button=ttk.Button(root,text="Register",command=insert2)
    register_button.pack()
    result_label = tk.StringVar()
    l=ttk.Label(root, textvariable=result_label)
    l.pack() 
    root.mainloop()