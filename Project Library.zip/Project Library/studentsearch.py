import mysql.connector
from tkinter import ttk
import tkinter as tk
import myconnect as d
def search2():
    root=tk.Toplevel()
    ttk.Label(root,text="Search").pack()
    l=ttk.Label(root)
    root.iconbitmap("abhi.ico")
    root.geometry('800x800+200+200')
    # ttk.Label(root,text="Book name").pack()

    ttk.Label(root,text="Student Id").pack()
    m=tk.IntVar()
    enter_id=ttk.Entry(root,textvariable=m)
    enter_id.focus()
    enter_id.pack()

    ttk.Label(root,text="Student Name").pack()
    m=tk.StringVar()
    enter_id=ttk.Entry(root,textvariable=m)
    enter_id.focus()
    enter_id.pack()

    ttk.Label(root,text="Email Id").pack()
    o=tk.StringVar()
    enter_email=ttk.Entry(root,textvariable=o)
    enter_email.focus()
    enter_email.pack()

    ttk.Label(root,text="Phone Number").pack()
    p=tk.StringVar()
    enter_contact=ttk.Entry(root,textvariable=p)
    enter_contact.focus()
    enter_contact.pack()

    result_label = tk.StringVar()

    def search():
        m=enter_id.get()
        # o=enter_email.get()
        query3=f"select * from students where Student_Id='{m}'"
        MyCur=d.getInfo(query3)
    # except mysql.connector.errors.ProgrammingError as v:
            # result_label.set(f"{v}")
            # conn = mysql.connector.connect\
                # (host= "localhost", user = "root",passwd= "1234",auth_plugin='mysql_native_password',database='library')  
            # MyCur=conn.cursor()
            # MyCur.execute(query3)
        if type(MyCur) is int:
            result_label.set(MyCur)
        else:
            for x in MyCur:
                result_label.set(f"Name:{x[1]}\nEmail:{x[2]}\nContact:{x[3]}\nSemester:{x[4]}")
                break
            else:
                result_label.set("No records")
        # except mysql.connector.Error as d:
            # result_label.set(f"{d}")

    search_button=ttk.Button(root,text="Search",command=search)
    search_button.pack()

    l=ttk.Label(root, textvariable=result_label)
    l.pack() 
    root.mainloop()