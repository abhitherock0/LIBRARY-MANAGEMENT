import mysql.connector
import tkinter as tk
import tkinter as Tk
from tkinter import ttk
import myconnect as d

def abhi6():
    root = tk.Toplevel()
    root.configure(bg='dark slate grey')
    tk.Label(root, text="Feedback Form", fg='light gray', bg='dark orchid', width=50, font=('Arial', 40)).pack()
    root.iconbitmap("abhi.ico")
    root.geometry('800x800+200+200')
    ttk.Label(root, text="Student_Id").pack()
    m = tk.IntVar()
    enter_id = ttk.Entry(root, textvariable=m)
    enter_id.focus()
    enter_id.pack()

    ttk.Label(root, text="Name").pack()
    n = tk.StringVar()
    enter_name = ttk.Entry(root, textvariable=n)
    enter_name.focus()
    enter_name.pack()

    ttk.Label(root, text="Feedback").pack()
    o = tk.StringVar()
    enter_feedback = ttk.Entry(root, textvariable=o)
    enter_feedback.focus()
    enter_feedback.pack()

    def insert1():
        student_id = enter_id.get()
        name = enter_name.get()
        feedback = enter_feedback.get()

        query = f"insert into feedback values({student_id}, '{name}', '{feedback}')"
        MyCur=d.updateInfo(query)
        # conn = mysql.connector.connect(
        #     host="localhost",
        #     user="root",
        #     passwd="1234",
        #     auth_plugin='mysql_native_password',
        #     database='library'
        # )
        if type(MyCur) is int:
            result_label.set("Thanks for the valuable feedback!")
        else:
            result_label.set(MyCur)
            
        # MyCur = conn.cursor()
        # MyCur.execute(query)
        # conn.commit()
        # conn.close()

    submit_button = tk.Button(root, text="Submit", command=insert1,width=30,bg='light blue',fg='black',font='Arial')
    submit_button.place(width=70, x=365, y=200)
    result_label = tk.StringVar()
    # l = ttk.Label(root, textvariable=result_label)
    # l.pack()
    root.mainloop()