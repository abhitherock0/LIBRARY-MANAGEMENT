import mysql.connector
# try:
conn = mysql.connector.connect\
        (host= "localhost", user = "root",passwd= "1234",auth_plugin='mysql_native_password',database='library')  

# except mysql.connector.Error as v:
#     result_label.set(f" Error of Database: {v}")
MyCur=conn.cursor()

def updateInfo(query):
    try:
        MyCur.execute(query)
        conn.commit()
    except mysql.connector.errors.ProgrammingError as f:
        return f
    return 10
def getInfo(query):
    try:
        MyCur.execute(query)
    except mysql.connector.errors.ProgrammingError as f:
        return f
    return MyCur