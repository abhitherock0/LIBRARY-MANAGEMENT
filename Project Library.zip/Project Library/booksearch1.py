import mysql.connector
from tkinter import ttk
import tkinter as tk
import myconnect as d
def search2():
    root=tk.Toplevel()
    ttk.Label(root,text="Form").pack()
    l=ttk.Label(root)
    root.iconbitmap("abhi.ico")
    root.geometry('800x800+200+200')
    ttk.Label(root,text="Book name").pack()
    n=tk.StringVar()
    enter_name=ttk.Entry(root,textvariable=n)
    enter_name.focus()
    enter_name.pack()

    ttk.Label(root,text="Author").pack()
    o=tk.StringVar()
    enter_author=ttk.Entry(root,textvariable=o)
    enter_author.focus()
    enter_author.pack()

    ttk.Label(root,text="Publicationyear").pack()
    p=tk.IntVar()
    enter_publicationyear=ttk.Entry(root,textvariable=p)
    enter_publicationyear.focus()
    enter_publicationyear.pack()

    result_label = tk.StringVar()

    def search():
        n=enter_name.get()
        o=enter_author.get()
        p=enter_publicationyear.get()
        query3=f"select * from books where Book_Name='{n}'and Author='{o}'and Publication_Year={p}"
        MyCur=d.getInfo(query3)
        # # c.search(query3)
        # conn = mysql.connector.connect\
        #     (host= "localhost", user = "root",passwd= "1234",auth_plugin='mysql_native_password',database='library')  
        # MyCur=conn.cursor()
        # MyCur.execute(query3)
        if type(MyCur) is int:
            result_label.set(f"Yes, {n} is available at price {x[4]}")
        else:
            for x in MyCur:
                result_label.set(   MyCur)
                break
            else:
                result_label.set("Not available")

    search_button=ttk.Button(root,text="Search",command=search)
    search_button.pack()

    l=ttk.Label(root, textvariable=result_label)
    l.pack() 
    root.mainloop()