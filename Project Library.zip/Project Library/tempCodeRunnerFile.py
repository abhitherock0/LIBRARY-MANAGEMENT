image_label=tk.Label(root,image=photo)
# image_label.place(x=230,y=220,width=350,height=300)