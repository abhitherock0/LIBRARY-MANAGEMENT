import tkinter as tk
import mysql.connector
import tkinter as Tk
from tkinter import ttk
root=
l=ttk.Label()
ttk.Label(root,text="Issue Book").pack()
# root.iconbitmap("abhi.ico")
root.geometry('800x800+200+200')
ttk.Label(root,text="Issuance Id").pack()
m=tk.IntVar()
enter_id=ttk.Entry(root,textvariable=m)
enter_id.focus()
enter_id.pack()

ttk.Label(root,text="Book Id").pack()
n=tk.IntVar()
enter_bid=ttk.Entry(root,textvariable=n)
enter_bid.focus()
enter_bid.pack()

ttk.Label(root,text="Student Id").pack()
o=tk.IntVar()
enter_sid=ttk.Entry(root,textvariable=o)
enter_sid.focus()
enter_sid.pack()

ttk.Label(root,text="Issuance Date").pack()
p=tk.StringVar()
enter_date=ttk.Entry(root,textvariable=p)
enter_date.focus()
enter_date.pack()

ttk.Label(root,text="Return Date").pack()
q=tk.StringVar()
enter_rdate=ttk.Entry(root,textvariable=q)
enter_rdate.focus()
enter_rdate.pack()


# def insert2():
#     m=enter_id.get()
#     n=enter_bid.get()
#     o=enter_sid.get()
#     p=enter_date.get()
#     q=enter_rdate.get()
        
# register_button=ttk.Button(root,text="Register")
# register_button.pack()
# result_label = tk.StringVar()
# l=ttk.Label(root, textvariable=result_label)
l.pack() 
root.mainloop()