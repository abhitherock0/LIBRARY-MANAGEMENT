import mysql.connector
import tkinter as tk
from tkinter import ttk
import myconnect as d
def register():
    root=tk.Toplevel()
    ttk.Label(root,text="Student Login").pack()
    l=ttk.Label(root)
    root.iconbitmap("abhi.ico")
    root.geometry('800x800+200+200')
    ttk.Label(root,text="Student_Id").pack()
    m=tk.IntVar()
    enter_id=ttk.Entry(root,textvariable=m)
    enter_id.focus()
    enter_id.pack()

    ttk.Label(root,text="Name").pack()
    n=tk.StringVar()
    enter_name=ttk.Entry(root,textvariable=n)
    enter_name.focus()
    enter_name.pack()

    ttk.Label(root,text="email_id").pack()
    o=tk.StringVar()
    enter_email=ttk.Entry(root,textvariable=o)
    enter_email.focus()
    enter_email.pack()

    ttk.Label(root,text="Phone_Number").pack()
    p=tk.StringVar()
    enter_contact=ttk.Entry(root,textvariable=p)
    enter_contact.focus()
    enter_contact.pack()

    ttk.Label(root,text="Semester").pack()
    q=tk.IntVar()
    enter_semester=ttk.Entry(root,textvariable=q)
    enter_semester.focus()
    enter_semester.pack()

    def insert():
        # try:
            m=enter_id.get()
            n=enter_name.get()
            o=enter_email.get()
            p=enter_contact.get()
            q=enter_semester.get()
            query=f"insert into students values({m},'{n}','{o}','{p}',{q})"
            MyCur=d.updateInfo(query)
            # print(MyCur)
            # print(type(MyCur))
            if type(MyCur) is int:
                result_label.set("Inserted Success")
            else:
                result_label.set(MyCur)
            # except mysql.connector.errors.ProgrammingError as v:
            # result_label.set(f"{v}")
            # # c.updateTable(query)
            # conn = mysql.connector.connect\
            # (host= "localhost", user = "root",passwd= "1234",auth_plugin='mysql_native_password',database='library')  
            # result_label.set("Insertion Success")
            # MyCur=conn.cursor()
            # MyCur.execute(query)
        # except mysql.connector.Error as h:
            # result_label.set(f"{h}")
            # conn.commit()
            # conn.close()

    register_button=ttk.Button(root,text="Register",command=insert)
    register_button.pack()
    result_label = tk.StringVar()
    l=ttk.Label(root, textvariable=result_label)
    l.pack() 
    root.mainloop()