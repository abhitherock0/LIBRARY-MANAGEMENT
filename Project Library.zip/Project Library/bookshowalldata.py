import mysql.connector
from tkinter import ttk
import tkinter as Tk
import tkinter as tk
import myconnect as c
def showall():
    ws = Tk.Toplevel()
    ws.title('PythonGuides')
    # ws.geometry('400x300')
    ws['bg'] = 'yellow'

    query1=f"describe books"
    MyCur=c.getInfo(query1)
    result_label=tk.StringVar()
    l=ttk.Label(ws, textvariable=result_label)
    # if type(MyCur) is str:
    #     result_label.set(MyCur)
    # else:
    #     result_label.set("No records")
    columns=('Rid','Book_Name','Author','Publication_Year','Price')
    tv=ttk.Treeview(ws,columns=columns)
    for y in MyCur:
        tv.heading(y[0],text=y[0],anchor=Tk.CENTER)
    tv.column('#0',width=0,stretch=Tk.NO)
    tv.column('Rid',anchor=Tk.CENTER,width=80)
    tv.column('Book_Name',anchor=Tk.CENTER,width=80)
    tv.column('Author',anchor=Tk.CENTER,width=80)
    tv.column('Publication_Year',anchor=Tk.CENTER,width=80)
    tv.column('Price',anchor=Tk.CENTER,width=80)

    query="select * from books order by Rid desc"
    MyCur=c.getInfo(query)

    for x in MyCur:
        tv.insert(parent='',index=0,values=x)
        
    tv.pack()
    ws.mainloop()