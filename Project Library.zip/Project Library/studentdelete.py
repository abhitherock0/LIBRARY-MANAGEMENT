import mysql.connector
import tkinter as tk
from tkinter import ttk
import myconnect as d
def delete1():
    root=tk.Toplevel()
    ttk.Label(root,text="Delete").pack()
    l=ttk.Label(root)
    root.iconbitmap("abhi.ico")
    root.geometry('800x800+200+200')

    ttk.Label(root,text="Student Id").pack()
    m=tk.IntVar()
    enter_id=ttk.Entry(root,textvariable=m)
    enter_id.focus()
    enter_id.pack()

    ttk.Label(root,text="Name").pack()
    n=tk.StringVar()
    enter_name=ttk.Entry(root,textvariable=n)
    enter_name.focus()
    enter_name.pack()

    ttk.Label(root,text="Email id").pack()
    o=tk.StringVar()
    enter_email=ttk.Entry(root,textvariable=o)
    enter_email.focus()
    enter_email.pack()

    ttk.Label(root,text="Phone Number").pack()
    p=tk.StringVar()
    enter_contact=ttk.Entry(root,textvariable=p)
    enter_contact.focus()
    enter_contact.pack()

    ttk.Label(root,text="Semester").pack()
    q=tk.IntVar()
    enter_semester=ttk.Entry(root,textvariable=q)
    enter_semester.focus()
    enter_semester.pack()

    def delete():
        # try:
            x=enter_id.get()
            query1=(f"delete from students where Student_Id={x}")
            MyCur=d.updateInfo(query1)
            if type(MyCur) is int:
                result_label.set("Deleted Sucessfully") 
            else:
                result_label.set(MyCur)

    delete_button=ttk.Button(root,text="Delete",command=delete)
    delete_button.pack()

    result_label = tk.StringVar()
    l=ttk.Label(root, textvariable=result_label)
    l.pack() 
    root.mainloop()