import mysql.connector
import booksearch1 as d
import bookinsert as e
import bookdelete as f
import bookshowalldata as h
import bookupdate as g
import connect1 as c
from tkinter import ttk
import tkinter as tk

def abhii():
    root=tk.Toplevel()
    root.configure(bg='black')
    tk.Label(root,text="REGISTER BOOK",fg='blue',bg='Pink',width=50,font=('Arial',35)).pack()
    root.iconbitmap("abhi.ico")
    root.geometry('800x800+200+200')

    def search3():
        d.search2()

    def register1():
        e.register()

    def delete2():
        f.delete1()

    def update2():
        g.update1()

    def showall1():
        h.showall()


    search_button=tk.Button(root,text="Search",command=search3,width=30,bg='green',fg='white',font='Arial')
    search_button.place(height=50,x=266,y=105)

    register_button=tk.Button(root,text="Register",command=register1,bg='red',fg='white',width=30,font='Arial')
    register_button.place(height=50,x=266,y=150)

    delete_button=tk.Button(root,text="Delete",command=delete2,bg='green',fg='white',width=30,font='Arial')
    delete_button.place(height=50,x=266,y=195)

    update_button=tk.Button(root,text="Update",command=update2,bg='red',fg='white',width=30,font='Arial')
    update_button.place(height=50,x=266,y=240)

    show_button=tk.Button(root,text="Show All",command=showall1,bg='green',fg='white',width=30,font='Arial')
    show_button.place(height=50,x=266,y=285)

    root.mainloop()