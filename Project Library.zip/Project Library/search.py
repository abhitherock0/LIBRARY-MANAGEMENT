import mysql.connector
import tkinter as tk
from tkinter import ttk
root=tk.Tk()
ttk.Label(root,text="Form").pack()
l=ttk.Label(root)
# root.iconbitmap("abhi.ico")
root.geometry('800x800+200+200')

ttk.Label(root,text="Rid").pack()
m=tk.IntVar()
enter_id=ttk.Entry(root,textvariable=m)
enter_id.focus()
enter_id.pack()

ttk.Label(root,text="Book name").pack()
n=tk.StringVar()
enter_name=ttk.Entry(root,textvariable=n)
enter_name.focus()
enter_name.pack()

ttk.Label(root,text="Author").pack()
o=tk.StringVar()
enter_author=ttk.Entry(root,textvariable=o)
enter_author.focus()
enter_author.pack()

ttk.Label(root,text="Publicationyear").pack()
p=tk.IntVar()
enter_publicationyear=ttk.Entry(root,textvariable=p)
enter_publicationyear.focus()
enter_publicationyear.pack()

ttk.Label(root,text="Price").pack()
q=tk.IntVar()
enter_price=ttk.Entry(root,textvariable=q)
enter_price.focus()
enter_price.pack()

def search():
    m=enter_id.get()
    query3=f"select Book_Name from books where Rid={m}"
    conn = mysql.connector.connect\
        (host= "localhost", user = "root",passwd= "1234",auth_plugin='mysql_native_password',database='library')  
    MyCur=conn.cursor()
    MyCur.execute(query3)
    result = MyCur.fetchone()
    if result is not None:
        result_label.set(f"Book Name:{result[0]}")
        # result_label.set(f"Rid: {result[0]}, Book Name: {result[1]}, Author: {result[2]}, Publication Year: {result[3]}, Price: {result[4]}")
    else:
        result_label.set("No record found.")

    conn.commit()
    conn.close()

search_button=ttk.Button(root,text="Search",command=search)
search_button.pack()

result_label = tk.StringVar()
l=ttk.Label(root, textvariable=result_label)
l.pack() 
root.mainloop()