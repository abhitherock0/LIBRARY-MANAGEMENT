import mysql.connector
import tkinter as tk
# import tkinter as Tk
from tkinter import ttk
import allbuttons as c
import studentpage as d
import issue as z
import feedbackbystudent as g

root=tk.Tk()
root.configure(bg='dark slate grey')
tk.Label(root,text="Home Page",fg='light gray',bg='dark orchid',width=50,font=('Arial',40)).pack()
root.iconbitmap("abhi.ico")
root.geometry('800x800+200+200')
# photo=tk.PhotoImage(file="library5.png")
# image_label=tk.Label(root)
# image_label.place(x=230,y=220,width=350,height=300)

def abhi1():
    c.abhii()

def abhi2():
    d.abhiii()

def abhi3():
    g.abhi6()

def abhi10():
    z.project()

abhi_button=tk.Button(root,text="Register Book",command=abhi1,width=30,bg='light green',fg='black',font='Arial')
abhi_button.place(height=50,x=266,y=195)

abhi5_button=tk.Button(root,text="Register Student",command=abhi2,width=30,bg='light blue',fg='black',font='Arial')
abhi5_button.place(height=50,x=266,y=240) 

feed_button=tk.Button(root,text="Feedback Form",command=abhi3,width=30,bg='light blue',fg='black',font='Arial')
feed_button.place(height=50,x=266 ,y=330)

issue_button=tk.Button(root,text="Issue Book",command=abhi10,width=30,bg='light green',fg='black',font='Arial')
issue_button.place(height=50,x=266 ,y=285)

root.mainloop()