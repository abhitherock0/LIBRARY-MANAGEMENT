import mysql.connector
import tkinter as tk
from tkinter import ttk
import myconnect as d
def update1():
    root=tk.Toplevel()
    ttk.Label(root,text="Form").pack()
    l=ttk.Label(root)
    root.iconbitmap("abhi.ico")
    root.geometry('800x800+200+200')

    ttk.Label(root,text="Rid").pack()
    m=tk.IntVar()
    enter_id=ttk.Entry(root,textvariable=m)
    enter_id.focus()
    enter_id.pack()

    ttk.Label(root,text="Book name").pack()
    n=tk.StringVar()
    enter_name=ttk.Entry(root,textvariable=n)
    enter_name.focus()
    enter_name.pack()

    ttk.Label(root,text="Author").pack()
    o=tk.StringVar()
    enter_author=ttk.Entry(root,textvariable=o)
    enter_author.focus()
    enter_author.pack()

    ttk.Label(root,text="Publication Year").pack()
    p=tk.IntVar()
    enter_publicationyear=ttk.Entry(root,textvariable=p)
    enter_publicationyear.focus()
    enter_publicationyear.pack()

    ttk.Label(root,text="Price").pack()
    q=tk.IntVar()
    enter_price=ttk.Entry(root,textvariable=q)
    enter_price.focus()
    enter_price.pack()

    def update():
        y=enter_id.get()
        n=enter_name.get()
        o=enter_author.get()
        p=enter_publicationyear.get()
        q=enter_price.get()
        query2=f"update books set Book_Name='{n}',Author='{o}',Publication_Year='{p}',Price={q} where Rid={y}"
        MyCur=d.updateInfo(query2)
        if type(MyCur) in int:
            result_label.set("Updated Sucessfully")
        else:
            result_label.set(MyCur)
        # conn = mysql.connector.connect\
        #     (host= "localhost", user = "root",passwd= "1234",auth_plugin='mysql_native_password',database='library')  
        # MyCur=conn.cursor()
        # MyCur.execute(query2)
        # conn.commit()
        # conn.close()
        
    result_label=tk.StringVar
    update_button=ttk.Button(root,text="Update",command=update)
    update_button.pack()

    l.pack() 
    root.mainloop()