import mysql.connector
import tkinter as tk
import tkinter as Tk
from tkinter import ttk
import myconnect as d

root=tk.Tk()
root.configure(bg='dark slate grey')
tk.Label(root,text="Login Page",fg='light gray',bg='dark orchid',width=50,font=('Arial',40)).pack()
root.iconbitmap("abhi.ico")
root.geometry('800x800+200+200')

tk.Label(root,text="Username",bg='light green',fg='black',font='Arial').place(x=300,y=150)
m=tk.StringVar()
enter_username=tk.Entry(root, textvariable=m, bg='light blue', fg='black')
enter_username.focus()
enter_username.place(x=400,y=150)

tk.Label(root,text="Password",bg='light green',fg='black',font='Arial').place(x=300,y=200)
n=tk.StringVar()
enter_pass=tk.Entry(root,textvariable=n,bg='light blue',fg='black')
enter_pass.focus()
enter_pass.place(x=400,y=200)

def user():
    m=enter_username.get()
    n=enter_pass.get()
    query=f"select * from loginpage where Username='{m}' and Password='{n}'"
    MyCur=d.getInfo(query)
    # print(type(MyCur))
    if type(MyCur) is str:
        result_label.set(MyCur)
    else:
        for x in MyCur:
            result_label.set("Sucessfully Logged In")
            break
        else:
            result_label.set("Incorrect Password")
    # try:
    #     m=enter_username.get()
    #     n=enter_pass.get()
    #     query=f"select * from loginpage where Username='{m}' and Password='{n}'"
    # except mysql.connector.errors.ProgrammingError as f:
    #     result_label.set(f"{v}")
    # try:
    #     conn = mysql.connector.connect\
    #     (host= "localhost", user = "root",passwd= "1234",auth_plugin='mysql_native_password',database='library')  
    #     MyCur=conn.cursor()
    #     MyCur.execute(query)
    #     for x in MyCur:
    #         result_label.set("Sucessfully Logged In")
    #         break
    #     else:
    #         result_label.set("Incorrect Password")
    # except mysql.connector.Error as v:
    #     result_label.set(f" Error of Database: {v}")
    # conn.commit()
    # conn.close()

def cancel():
    enter_username.delete(0,'end')
    enter_pass.delete(0,'end')

submit_button=tk.Button(root,text="Login",command=user,bg='grey',fg='gold',font='Arial')
submit_button.place(height=30,x=350,y=300)

cancel_button=tk.Button(root,text="Cancel",command=cancel,bg='grey',fg='gold',font='Arial')
cancel_button.place(height=30,x=410,y=300)

result_label = tk.StringVar()
l=ttk.Label(root, textvariable=result_label)

l.pack() 
root.mainloop()